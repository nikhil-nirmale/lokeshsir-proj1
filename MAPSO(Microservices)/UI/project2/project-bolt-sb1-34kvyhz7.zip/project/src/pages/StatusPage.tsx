import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Shield, AlertCircle, CheckCircle, XCircle, FileText, Download } from 'lucide-react';

import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import ProgressBar from '../components/ui/ProgressBar';
import Panel from '../components/ui/Panel';
import Badge from '../components/ui/Badge';
import { AnalysisResponse, CheckReportItem, ValidoStatus } from '../types';
import api from '../services/api';
import dbService from '../services/database';

const StatusPage: React.FC = () => {
  const { jobId: urlJobId } = useParams<{ jobId?: string }>();
  const [jobId, setJobId] = useState(urlJobId || '');
  const [jobData, setJobData] = useState<AnalysisResponse | null>(null);
  const [isPolling, setIsPolling] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [jsonDownloadUrl, setJsonDownloadUrl] = useState('');

  // Status color mappings
  const statusColors: Record<string, string> = {
    queued: 'bg-muted text-foreground',
    processing: 'bg-primary text-white',
    done: 'bg-success text-white',
    failed: 'bg-error text-white',
  };

  // Result status icons and colors
  const validoStatusConfig: Record<ValidoStatus, { icon: JSX.Element; color: string }> = {
    VALID: { 
      icon: <CheckCircle className="w-5 h-5" />, 
      color: 'success' 
    },
    INVALID: { 
      icon: <XCircle className="w-5 h-5" />, 
      color: 'error' 
    },
    UNKNOWN: { 
      icon: <AlertCircle className="w-5 h-5" />, 
      color: 'warning' 
    },
  };

  // Check result icon and color mapping
  const checkResultConfig: Record<string, { icon: JSX.Element; color: string }> = {
    PRESENT: { 
      icon: <CheckCircle className="w-5 h-5" />, 
      color: 'warning' 
    },
    NOT_DETECTED: { 
      icon: <CheckCircle className="w-5 h-5" />, 
      color: 'success' 
    },
    ERROR: { 
      icon: <AlertCircle className="w-5 h-5" />, 
      color: 'error' 
    },
    SKIPPED: { 
      icon: <AlertCircle className="w-5 h-5" />, 
      color: 'muted' 
    },
  };

  // Check type icons
  const checkTypeIcons: Record<string, JSX.Element> = {
    macro: <FileText className="w-5 h-5 text-warning" />,
    ads: <AlertCircle className="w-5 h-5 text-error" />,
    password: <Shield className="w-5 h-5 text-primary" />,
    steganography: <FileText className="w-5 h-5 text-secondary" />,
    ocr: <FileText className="w-5 h-5 text-accent" />,
  };

  // Function to fetch job status
  const fetchJobStatus = async (id: string) => {
    if (!id) return;
    
    setIsLoading(true);
    setError('');
    
    try {
      const response = await api.getJobStatus(id);
      setJobData(response);
      
      // Generate JSON download URL if result is available
      if (response.result) {
        const jsonString = JSON.stringify(response.result, null, 2);
        const url = dbService.generateJsonDownloadUrl(jsonString);
        setJsonDownloadUrl(url);
        
        // Update database record with result
        await dbService.updateFileRecord(id, {
          status: response.status,
          result_json: jsonString,
        });
      }
      
      // Continue polling if job is not complete
      if (response.status === 'queued' || response.status === 'processing') {
        setIsPolling(true);
      } else {
        setIsPolling(false);
      }
    } catch (err) {
      console.error('Error fetching job status:', err);
      setError('Failed to fetch job status');
      setIsPolling(false);
    } finally {
      setIsLoading(false);
    }
  };

  // Start polling when job ID changes
  useEffect(() => {
    if (urlJobId) {
      setJobId(urlJobId);
      fetchJobStatus(urlJobId);
    }
  }, [urlJobId]);

  // Set up polling interval
  useEffect(() => {
    let interval: number | undefined;
    
    if (isPolling) {
      interval = window.setInterval(() => {
        fetchJobStatus(jobId);
      }, 3000);
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isPolling, jobId]);

  // Handle manual job ID submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!jobId) {
      setError('Please enter a job ID');
      return;
    }
    
    fetchJobStatus(jobId);
  };

  // Render check result
  const renderCheckResult = (check: CheckReportItem) => {
    const config = checkResultConfig[check.result] || checkResultConfig.ERROR;
    const icon = checkTypeIcons[check.name] || <FileText className="w-5 h-5" />;
    
    return (
      <Panel
        key={check.name}
        title={
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center">
              {icon}
              <span className="ml-2 capitalize">{check.name} Check</span>
            </div>
            <Badge variant={config.color as any} size="md" className="flex items-center space-x-1">
              {config.icon}
              <span>{check.result}</span>
            </Badge>
          </div>
        }
        className="mb-4"
      >
        <div className="space-y-2">
          {check.error && (
            <div className="p-3 bg-error/10 border border-error/20 rounded text-sm">
              <p className="font-medium">Error:</p>
              <p>{check.error}</p>
            </div>
          )}
          {check.details && (
            <div className="mt-2">
              <p className="font-medium mb-1">Details:</p>
              <pre className="bg-muted/10 p-3 rounded text-sm overflow-x-auto">
                {JSON.stringify(check.details, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </Panel>
    );
  };

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
      <div className="flex items-center mb-6">
        <Shield className="mr-3 h-8 w-8 text-primary" />
        <h1 className="text-2xl font-bold">Job Status</h1>
      </div>

      {!urlJobId && (
        <form onSubmit={handleSubmit} className="mb-8">
          <Panel title="Check Job Status" defaultOpen={true}>
            <div className="flex flex-col md:flex-row gap-4">
              <Input
                label="Job ID"
                value={jobId}
                onChange={(e) => setJobId(e.target.value)}
                placeholder="Enter job ID"
                fullWidth
                className="flex-1"
              />
              <div className="flex items-end">
                <Button
                  type="submit"
                  variant="primary"
                  isLoading={isLoading}
                  disabled={isLoading || !jobId}
                >
                  Check Status
                </Button>
              </div>
            </div>
            {error && (
              <div className="mt-4 p-3 bg-error/10 border border-error/20 rounded text-sm text-error">
                {error}
              </div>
            )}
          </Panel>
        </form>
      )}

      {jobData && (
        <div>
          <div className="bg-card rounded-lg border border-border p-6 mb-6">
            <div className="flex flex-col md:flex-row justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold mb-1">Job: {jobData.job_id}</h2>
                <div className="flex items-center">
                  <span className={`inline-block w-2 h-2 rounded-full mr-2 ${
                    jobData.status === 'done' ? 'bg-success' :
                    jobData.status === 'failed' ? 'bg-error' :
                    jobData.status === 'processing' ? 'bg-primary' :
                    'bg-muted'
                  }`}></span>
                  <Badge
                    variant={
                      jobData.status === 'done' ? 'success' :
                      jobData.status === 'failed' ? 'error' :
                      jobData.status === 'processing' ? 'primary' :
                      'default'
                    }
                  >
                    {jobData.status.toUpperCase()}
                  </Badge>
                </div>
              </div>

              {jobData.result && (
                <div className="mt-4 md:mt-0">
                  <Button
                    variant="outline"
                    rightIcon={<Download className="w-4 h-4" />}
                    as="a"
                    href={jsonDownloadUrl}
                    download={`result-${jobData.job_id}.json`}
                  >
                    Download Results
                  </Button>
                </div>
              )}
            </div>

            {(jobData.status === 'queued' || jobData.status === 'processing') && (
              <ProgressBar
                value={jobData.progress}
                max={100}
                label="Processing"
                variant={jobData.status === 'processing' ? 'primary' : 'default'}
                animated={true}
              />
            )}

            {jobData.error && (
              <div className="mt-4 p-4 bg-error/10 border border-error/20 rounded-lg">
                <div className="flex items-start">
                  <AlertCircle className="w-5 h-5 text-error mr-2 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-error">Error</h3>
                    <p className="text-sm">{jobData.error}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {jobData.result && (
            <div className="space-y-6">
              <div className="bg-card rounded-lg border border-border p-6 mb-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Analysis Results</h2>
                  <Badge
                    variant={
                      jobData.result.valido_status === 'VALID' ? 'success' :
                      jobData.result.valido_status === 'INVALID' ? 'error' :
                      'warning'
                    }
                    size="lg"
                    className="flex items-center space-x-2"
                  >
                    {validoStatusConfig[jobData.result.valido_status]?.icon}
                    <span>{jobData.result.valido_status}</span>
                  </Badge>
                </div>

                {jobData.result.notes && (
                  <div className="mb-6 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                    <h3 className="font-medium text-primary mb-1">Notes</h3>
                    <p className="text-sm">{jobData.result.notes}</p>
                  </div>
                )}

                {jobData.result.derived_file_url && (
                  <div className="mb-6 p-4 bg-secondary/5 border border-secondary/20 rounded-lg">
                    <h3 className="font-medium text-secondary mb-1">Derived Document</h3>
                    <p className="text-sm mb-3">A sanitized version of this document is available for download.</p>
                    <Button
                      variant="secondary"
                      size="sm"
                      as="a"
                      href={jobData.result.derived_file_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      rightIcon={<Download className="w-4 h-4" />}
                    >
                      Download Derived Document
                    </Button>
                  </div>
                )}
              </div>

              <h3 className="font-bold text-lg mb-3">Security Check Results</h3>
              <div className="space-y-3">
                {jobData.result.checks.map(renderCheckResult)}
              </div>
            </div>
          )}

          <div className="mt-8 text-center">
            <Link to="/">
              <Button variant="outline">Upload Another Document</Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default StatusPage;